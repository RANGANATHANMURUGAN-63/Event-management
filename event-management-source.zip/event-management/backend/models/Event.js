const mongoose = require('mongoose');
const APP_TAG = 'eventsphere_ems_v2';

const eventSchema = new mongoose.Schema({
  appTag: { type: String, default: APP_TAG, index: true },
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  date: { type: Date, required: true },
  endDate: { type: Date },
  venue: { type: String, required: true },
  room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
  capacity: { type: Number, required: true, min: 1 },
  price: { type: Number, default: 0 },
  category: { type: String, enum: ['conference','workshop','seminar','social','other'], default: 'other' },
  status: { type: String, enum: ['pending','upcoming','ongoing','completed','cancelled'], default: 'pending' },
  organizer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  registered: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  createdAt: { type: Date, default: Date.now }
});

eventSchema.index({ title: 1, organizer: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('Event', eventSchema);
module.exports.APP_TAG = APP_TAG;

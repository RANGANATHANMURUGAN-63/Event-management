const router = require('express').Router();
const Registration = require('../models/Registration');
const Event = require('../models/Event');
const Notification = require('../models/Notification');
const { protect, attendeeOnly } = require('../middleware/auth');
const APP_TAG = 'eventsphere_ems_v2';

// Register - attendees only (req #11)
router.post('/:eventId', protect, attendeeOnly, async (req, res) => {
  try {
    const event = await Event.findOne({ _id: req.params.eventId, appTag: APP_TAG });
    if (!event) return res.status(404).json({ message: 'Event not found' });
    if (event.status === 'cancelled') return res.status(400).json({ message: 'This event has been cancelled' });
    if ((event.registered?.length || 0) >= event.capacity)
      return res.status(400).json({ message: 'Event is at full capacity' });

    const existing = await Registration.findOne({ event: event._id, user: req.user._id });
    if (existing) {
      if (existing.status !== 'cancelled')
        return res.status(400).json({ message: 'You are already registered for this event' });

      existing.status = event.price === 0 ? 'confirmed' : 'pending';
      existing.paymentStatus = event.price === 0 ? 'paid' : 'unpaid';
      existing.ticketId = `TKT-${Date.now()}-${Math.random().toString(36).substr(2,6).toUpperCase()}`;
      existing.registeredAt = new Date();
      await existing.save();
      event.registered.push(req.user._id);
      await event.save();
      return res.status(201).json(existing);
    }

    const reg = await Registration.create({
      event: event._id,
      user: req.user._id,
      appTag: APP_TAG,
      amount: event.price,
      status: event.price === 0 ? 'confirmed' : 'pending',
      paymentStatus: event.price === 0 ? 'paid' : 'unpaid'
    });
    event.registered.push(req.user._id);
    await event.save();
    await Notification.create({
      user: req.user._id,
      appTag: APP_TAG,
      message: `You registered for "${event.title}"`,
      type: 'success'
    });
    res.status(201).json(reg);
  } catch (err) {
    if (err.code === 11000) return res.status(400).json({ message: 'You are already registered for this event' });
    res.status(500).json({ message: err.message });
  }
});

// Cancel registration
router.put('/:eventId/cancel', protect, async (req, res) => {
  try {
    const reg = await Registration.findOne({ event: req.params.eventId, user: req.user._id });
    if (!reg) return res.status(404).json({ message: 'Registration not found' });
    reg.status = 'cancelled';
    await reg.save();
    await Event.findByIdAndUpdate(req.params.eventId, { $pull: { registered: req.user._id } });
    await Notification.create({
      user: req.user._id,
      appTag: APP_TAG,
      message: 'Your registration has been cancelled',
      type: 'warning'
    });
    res.json({ message: 'Registration cancelled' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// My registrations
router.get('/my/list', protect, async (req, res) => {
  try {
    const regs = await Registration.find({ user: req.user._id, appTag: APP_TAG })
      .populate('event', 'title date venue status price')
      .sort({ registeredAt: -1 });
    res.json(regs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
